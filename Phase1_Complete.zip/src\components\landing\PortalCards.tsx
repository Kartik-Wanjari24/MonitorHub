import React, { useState } from 'react';
import { useLanguage } from '../../i18n/useLanguage';
import {
  Stethoscope,
  ClipboardList,
  HeartPulse,
  ArrowRight,
  ShieldAlert,
  KeyRound,
  Mail,
  Lock,
  X,
  Sparkles,
} from 'lucide-react';

interface PortalRoleModalData {
  roleName: string;
  roleBadge: string;
  description: string;
  email: string;
  password: string;
  features: string[];
}

export const PortalCards: React.FC = () => {
  const { t } = useLanguage();
  const [activeModal, setActiveModal] = useState<PortalRoleModalData | null>(null);

  const portals = [
    {
      id: 'doctor',
      title: t.portals.doctorTitle,
      badge: t.portals.doctorBadge,
      description: t.portals.doctorDesc,
      cta: t.portals.doctorCta,
      icon: Stethoscope,
      accentColor: 'from-blue-600 to-indigo-700',
      badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
      hoverBorder: 'hover:border-blue-500',
      buttonBg: 'bg-blue-600 hover:bg-blue-700 text-white',
      demoEmail: 'doctor@demo.com',
      demoPassword: 'Doctor123',
      features: [
        'Smart Consultation Queue',
        '3D Interactive Anatomy View',
        'Longitudinal Vitals Assessment',
        'Clinical Notes & Handover',
      ],
    },
    {
      id: 'staff',
      title: t.portals.staffTitle,
      badge: t.portals.staffBadge,
      description: t.portals.staffDesc,
      cta: t.portals.staffCta,
      icon: ClipboardList,
      accentColor: 'from-sky-600 to-blue-700',
      badgeColor: 'bg-sky-100 text-sky-800 border-sky-200',
      hoverBorder: 'hover:border-sky-500',
      buttonBg: 'bg-sky-600 hover:bg-sky-700 text-white',
      demoEmail: 'staff@demo.com',
      demoPassword: 'Staff123',
      features: [
        'Rapid Patient Registration & Unique IDs',
        'OPD Queue Priority & Triage',
        'Appointment Scheduling & Doctors Slotting',
        'Emergency Case Intake Tracking',
      ],
    },
    {
      id: 'patient',
      title: t.portals.patientTitle,
      badge: t.portals.patientBadge,
      description: t.portals.patientDesc,
      cta: t.portals.patientCta,
      icon: HeartPulse,
      accentColor: 'from-emerald-600 to-teal-700',
      badgeColor: 'bg-emerald-100 text-emerald-800 border-emerald-200',
      hoverBorder: 'hover:border-emerald-500',
      buttonBg: 'bg-emerald-600 hover:bg-emerald-700 text-white',
      demoEmail: 'patient@demo.com',
      demoPassword: 'Patient123',
      features: [
        'Simplified Health Diary & Vitals View',
        'Live OPD Wait Time & Queue Tracking',
        'Diagnostic Test Reports & Prescriptions',
        'Prominent One-Tap "Call for Help"',
      ],
    },
  ];

  const handleCardClick = (portal: (typeof portals)[0]) => {
    setActiveModal({
      roleName: portal.title,
      roleBadge: portal.badge,
      description: portal.description,
      email: portal.demoEmail,
      password: portal.demoPassword,
      features: portal.features,
    });
  };

  const closeModal = () => {
    setActiveModal(null);
  };

  return (
    <section id="portals" className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Heading */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/80">
            <Sparkles className="w-3.5 h-3.5" />
            <span>{t.portals.sectionBadge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.portals.sectionTitle}
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            {t.portals.sectionSubtitle}
          </p>
        </div>

        {/* 3 Portal Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {portals.map((portal) => {
            const Icon = portal.icon;
            return (
              <div
                key={portal.id}
                className={`flex flex-col justify-between bg-slate-50/70 hover:bg-white rounded-2xl p-7 border border-slate-200/80 shadow-xs hover:shadow-xl transition-all duration-300 group ${portal.hoverBorder}`}
              >
                <div>
                  {/* Top Bar: Icon & Role Badge */}
                  <div className="flex items-center justify-between mb-6">
                    <div
                      className={`w-14 h-14 rounded-2xl bg-gradient-to-tr ${portal.accentColor} text-white flex items-center justify-center shadow-md group-hover:scale-105 transition-transform`}
                    >
                      <Icon className="w-7 h-7" />
                    </div>
                    <span
                      className={`text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-md border ${portal.badgeColor}`}
                    >
                      {portal.badge}
                    </span>
                  </div>

                  {/* Title & Description */}
                  <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-blue-600 transition-colors">
                    {portal.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    {portal.description}
                  </p>
                </div>

                {/* Bottom Action */}
                <div className="pt-4 border-t border-slate-200/60">
                  <button
                    type="button"
                    onClick={() => handleCardClick(portal)}
                    className={`w-full inline-flex items-center justify-center gap-2 px-5 py-3 rounded-xl font-semibold text-sm transition-all shadow-xs hover:shadow-md focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 active:scale-95 ${portal.buttonBg}`}
                  >
                    <span>{portal.cta}</span>
                    <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Role Preview Modal for Phase 1 */}
      {activeModal && (
        <div
          role="dialog"
          aria-modal="true"
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in"
        >
          <div className="bg-white rounded-2xl max-w-lg w-full p-6 sm:p-7 shadow-2xl border border-slate-200 space-y-5 animate-in zoom-in-95">
            {/* Modal Header */}
            <div className="flex items-start justify-between">
              <div>
                <span className="text-xs font-semibold uppercase text-blue-600 tracking-wider">
                  {activeModal.roleBadge}
                </span>
                <h3 className="text-xl font-bold text-slate-900 mt-1">
                  {activeModal.roleName}
                </h3>
              </div>
              <button
                type="button"
                onClick={closeModal}
                className="p-1.5 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-lg transition-colors"
                aria-label="Close dialog"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Notice */}
            <div className="p-3.5 rounded-xl bg-amber-50 border border-amber-200/80 text-amber-900 text-xs flex gap-3">
              <ShieldAlert className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold">{t.portals.modalTitle}</p>
                <p className="mt-0.5 leading-relaxed text-amber-800">
                  {t.portals.modalNotice}
                </p>
              </div>
            </div>

            {/* Description */}
            <p className="text-sm text-slate-600 leading-relaxed">
              {activeModal.description}
            </p>

            {/* Upcoming Features Preview */}
            <div className="space-y-2">
              <p className="text-xs font-bold uppercase tracking-wider text-slate-500">
                Key Portal Capabilities
              </p>
              <ul className="grid sm:grid-cols-2 gap-2">
                {activeModal.features.map((feat, idx) => (
                  <li
                    key={idx}
                    className="text-xs text-slate-700 bg-slate-50 p-2 rounded-lg border border-slate-100 flex items-center gap-2"
                  >
                    <span className="w-1.5 h-1.5 rounded-full bg-blue-600"></span>
                    <span>{feat}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Credentials Preview */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 space-y-2">
              <div className="flex items-center gap-1.5 text-xs font-semibold text-slate-700">
                <KeyRound className="w-3.5 h-3.5 text-blue-600" />
                <span>{t.portals.modalCredentials}</span>
              </div>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 block flex items-center gap-1">
                    <Mail className="w-3 h-3" /> {t.portals.modalEmail}
                  </span>
                  <code className="text-slate-800 font-mono font-medium">
                    {activeModal.email}
                  </code>
                </div>
                <div className="bg-white p-2 rounded-lg border border-slate-200">
                  <span className="text-[10px] text-slate-400 block flex items-center gap-1">
                    <Lock className="w-3 h-3" /> {t.portals.modalPassword}
                  </span>
                  <code className="text-slate-800 font-mono font-medium">
                    {activeModal.password}
                  </code>
                </div>
              </div>
            </div>

            {/* Close Button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={closeModal}
                className="w-full py-2.5 px-4 rounded-xl font-semibold text-sm text-slate-700 bg-slate-100 hover:bg-slate-200 transition-colors"
              >
                {t.portals.modalClose}
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
