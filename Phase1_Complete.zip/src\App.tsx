import React, { useState } from 'react';
import { LanguageProvider } from './i18n/LanguageContext';
import { Navbar } from './components/navigation/Navbar';
import { Hero } from './components/landing/Hero';
import { PortalCards } from './components/landing/PortalCards';
import { FeaturesSection } from './components/landing/FeaturesSection';
import { PlatformIntro } from './components/landing/PlatformIntro';
import { CTASection } from './components/landing/CTASection';
import { Footer } from './components/navigation/Footer';
import { PhaseNoticeModal } from './components/common/PhaseNoticeModal';

const LandingPageContent: React.FC = () => {
  const [phaseModalFeature, setPhaseModalFeature] = useState<string | null>(null);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-800">
      {/* 1.1 Navigation Bar */}
      <Navbar
        onOpenPhaseNotice={(feature) => setPhaseModalFeature(feature)}
        onNavigateToPortals={() => scrollToSection('portals')}
        onNavigateToServices={() => scrollToSection('services')}
      />

      {/* Main Page Sections */}
      <main className="flex-1">
        {/* 1.2 Hero Section */}
        <Hero
          onGetStarted={() => scrollToSection('portals')}
          onExploreServices={() => scrollToSection('services')}
        />

        {/* 1.3 Three Portal Cards */}
        <PortalCards />

        {/* 1.4 Key Features Section */}
        <FeaturesSection />

        {/* 1.5 Platform Introduction */}
        <PlatformIntro />

        {/* 1.6 Get Started / Closing CTA Section */}
        <CTASection
          onSelectPortal={() => scrollToSection('portals')}
          onOpenDocNotice={() => setPhaseModalFeature('Platform Roadmap & Architecture')}
        />
      </main>

      {/* 1.7 Footer */}
      <Footer
        onOpenPhaseNotice={(feature) => setPhaseModalFeature(feature)}
        onNavigateToPortals={() => scrollToSection('portals')}
      />

      {/* Phase 2 Informational Modal */}
      <PhaseNoticeModal
        featureName={phaseModalFeature}
        onClose={() => setPhaseModalFeature(null)}
      />
    </div>
  );
};

export const App: React.FC = () => {
  return (
    <LanguageProvider>
      <LandingPageContent />
    </LanguageProvider>
  );
};

export default App;
