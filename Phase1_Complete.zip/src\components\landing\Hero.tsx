import React from 'react';
import { useLanguage } from '../../i18n/useLanguage';
import {
  ArrowRight,
  Sparkles,
  Heart,
  Activity,
  Users,
  Shield,
  Clock,
  CheckCircle2,
  Stethoscope,
  Building2,
  UserCheck,
} from 'lucide-react';

interface HeroProps {
  onGetStarted: () => void;
  onExploreServices: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onGetStarted, onExploreServices }) => {
  const { t } = useLanguage();

  return (
    <section
      id="home"
      className="relative pt-32 pb-20 md:pt-40 md:pb-28 overflow-hidden bg-gradient-to-b from-blue-50/70 via-white to-slate-50"
    >
      {/* Background Decor Elements */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-full max-w-7xl h-96 pointer-events-none opacity-40">
        <div className="absolute -top-16 left-10 w-72 h-72 bg-blue-300 rounded-full blur-3xl mix-blend-multiply"></div>
        <div className="absolute -top-12 right-12 w-80 h-80 bg-sky-200 rounded-full blur-3xl mix-blend-multiply"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Hero Copy & Actions */}
          <div className="lg:col-span-7 text-center lg:text-left space-y-6">
            {/* Badge */}
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full text-xs font-semibold bg-blue-100/80 text-blue-800 border border-blue-200/60 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-blue-600" />
              <span>{t.hero.badge}</span>
            </div>

            {/* Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-slate-900 leading-[1.15]">
              {t.hero.headline}
            </h1>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg text-slate-600 max-w-2xl mx-auto lg:mx-0 leading-relaxed">
              {t.hero.supportingText}
            </p>

            {/* Call To Action Buttons */}
            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
              <button
                type="button"
                onClick={onGetStarted}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2.5 px-7 py-3.5 text-base font-semibold text-white bg-blue-600 hover:bg-blue-700 rounded-xl shadow-md hover:shadow-lg hover:shadow-blue-600/20 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 active:scale-95"
              >
                <span>{t.hero.getStarted}</span>
                <ArrowRight className="w-4 h-4" />
              </button>

              <button
                type="button"
                onClick={onExploreServices}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3.5 text-base font-semibold text-slate-700 bg-white hover:bg-slate-50 border border-slate-200/90 rounded-xl shadow-xs hover:border-slate-300 transition-all focus:outline-none focus-visible:ring-2 focus-visible:ring-blue-600"
              >
                <span>{t.hero.exploreServices}</span>
              </button>
            </div>

            {/* Trust Badges */}
            <div className="pt-6 border-t border-slate-200/70 flex flex-wrap items-center justify-center lg:justify-start gap-6 text-xs text-slate-500">
              <div className="flex items-center gap-2">
                <Shield className="w-4 h-4 text-emerald-600" />
                <span>{t.hero.securityBadge}</span>
              </div>
              <div className="flex items-center gap-2">
                <Users className="w-4 h-4 text-blue-600" />
                <span>{t.hero.activeUsersText}</span>
              </div>
            </div>
          </div>

          {/* Right Column: Visual Healthcare Coordination Widget */}
          <div className="lg:col-span-5 relative">
            {/* Visual Container */}
            <div className="relative mx-auto max-w-md lg:max-w-none bg-white/95 backdrop-blur-md rounded-2xl p-6 shadow-xl border border-blue-100/80">
              {/* Header of Preview Box */}
              <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                <div className="flex items-center gap-2.5">
                  <div className="w-3 h-3 rounded-full bg-emerald-500 animate-pulse"></div>
                  <span className="text-xs font-bold text-slate-700 tracking-wide uppercase">
                    Care Coordination Hub
                  </span>
                </div>
                <span className="text-[11px] font-medium px-2 py-0.5 rounded bg-blue-50 text-blue-700 border border-blue-100">
                  Unified System
                </span>
              </div>

              {/* Patient Care Stream Flow */}
              <div className="py-4 space-y-3.5">
                {/* 1. Reception / Staff intake */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center shrink-0">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-slate-800">
                        Hospital Reception
                      </p>
                      <span className="text-[10px] text-emerald-700 font-medium bg-emerald-50 px-1.5 py-0.5 rounded">
                        ID: TMH-8942
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate">
                      Patient intake registered & assigned to OPD Smart Queue
                    </p>
                  </div>
                </div>

                {/* 2. Doctor consultation workstation */}
                <div className="p-3 rounded-xl bg-blue-50/70 border border-blue-200/80 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-blue-600 text-white flex items-center justify-center shrink-0">
                    <Stethoscope className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-blue-950">
                        Doctor Clinical Workspace
                      </p>
                      <span className="text-[10px] text-blue-800 font-medium bg-blue-100/80 px-1.5 py-0.5 rounded flex items-center gap-1">
                        <Clock className="w-3 h-3" /> Ready
                      </span>
                    </div>
                    <p className="text-[11px] text-blue-800/80 truncate">
                      One-tap record assessment & vitals overview
                    </p>
                  </div>
                </div>

                {/* 3. Patient Mobile view */}
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-200/70 flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center shrink-0">
                    <UserCheck className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="text-xs font-semibold text-slate-800">
                        Patient Experience
                      </p>
                      <span className="text-[10px] text-slate-600 font-medium bg-slate-200/70 px-1.5 py-0.5 rounded">
                        Queue #03
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-500 truncate">
                      Transparent status, prescription reminders & health diary
                    </p>
                  </div>
                </div>
              </div>

              {/* Vitals Telemetry Preview Bar */}
              <div className="mt-2 pt-3 border-t border-slate-100 grid grid-cols-3 gap-2 text-center">
                <div className="bg-slate-50 p-2 rounded-lg">
                  <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                    <Heart className="w-3 h-3 text-rose-500" /> Pulse
                  </div>
                  <div className="text-sm font-bold text-slate-800">72 bpm</div>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg">
                  <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                    <Activity className="w-3 h-3 text-blue-600" /> SpO₂
                  </div>
                  <div className="text-sm font-bold text-slate-800">99 %</div>
                </div>
                <div className="bg-slate-50 p-2 rounded-lg">
                  <div className="text-[10px] text-slate-500 flex items-center justify-center gap-1">
                    <CheckCircle2 className="w-3 h-3 text-emerald-600" /> BP
                  </div>
                  <div className="text-sm font-bold text-slate-800">120/80</div>
                </div>
              </div>

              {/* Subtle Label */}
              <p className="text-[10px] text-center text-slate-400 mt-3 italic">
                * Simulated healthcare coordination preview for demonstration
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
