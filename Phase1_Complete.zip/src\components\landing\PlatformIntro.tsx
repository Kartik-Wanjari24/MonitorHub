import React from 'react';
import { useLanguage } from '../../i18n/useLanguage';
import {
  Layers,
  ArrowRight,
  ClipboardCheck,
  Stethoscope,
  HeartHandshake,
  Info,
} from 'lucide-react';

export const PlatformIntro: React.FC = () => {
  const { t } = useLanguage();

  const steps = [
    {
      step: '01',
      title: t.platformIntro.staffStepTitle,
      description: t.platformIntro.staffStepDesc,
      icon: ClipboardCheck,
      color: 'bg-sky-50 text-sky-700 border-sky-200',
    },
    {
      step: '02',
      title: t.platformIntro.doctorStepTitle,
      description: t.platformIntro.doctorStepDesc,
      icon: Stethoscope,
      color: 'bg-blue-50 text-blue-700 border-blue-200',
    },
    {
      step: '03',
      title: t.platformIntro.patientStepTitle,
      description: t.platformIntro.patientStepDesc,
      icon: HeartHandshake,
      color: 'bg-emerald-50 text-emerald-700 border-emerald-200',
    },
  ];

  return (
    <section className="py-20 bg-white relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-50 text-blue-700 border border-blue-200/80">
            <Layers className="w-3.5 h-3.5" />
            <span>{t.platformIntro.sectionBadge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.platformIntro.sectionTitle}
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            {t.platformIntro.sectionSubtitle}
          </p>
        </div>

        {/* 3 Step Flow */}
        <div className="grid md:grid-cols-3 gap-8 relative">
          {steps.map((item, idx) => {
            const Icon = item.icon;
            const isLast = idx === steps.length - 1;
            return (
              <div
                key={item.step}
                className="relative bg-slate-50/70 rounded-2xl p-7 border border-slate-200/80 hover:bg-white hover:shadow-lg transition-all"
              >
                {/* Step Pill */}
                <div className="flex items-center justify-between mb-5">
                  <div
                    className={`w-12 h-12 rounded-xl flex items-center justify-center border ${item.color}`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <span className="text-2xl font-black text-slate-300">
                    {item.step}
                  </span>
                </div>

                <h3 className="text-lg font-bold text-slate-900 mb-2.5">
                  {item.title}
                </h3>
                <p className="text-sm text-slate-600 leading-relaxed">
                  {item.description}
                </p>

                {!isLast && (
                  <div className="hidden lg:block absolute -right-4 top-1/2 -translate-y-1/2 z-10 text-slate-300">
                    <ArrowRight className="w-6 h-6" />
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Prototype Safeguard / Medical Notice Card */}
        <div className="mt-12 p-5 rounded-2xl bg-blue-50/60 border border-blue-200/80 flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center shrink-0">
            <Info className="w-5 h-5" />
          </div>
          <div className="space-y-1">
            <h4 className="text-sm font-bold text-blue-950">
              {t.platformIntro.disclaimerTitle}
            </h4>
            <p className="text-xs text-blue-900/80 leading-relaxed">
              {t.platformIntro.disclaimerText}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
