export type Language = 'en' | 'hi';

export interface Translations {
  // Navigation
  nav: {
    brandName: string;
    brandTagline: string;
    home: string;
    aboutUs: string;
    services: string;
    contact: string;
    login: string;
    languageToggle: string;
    openMenu: string;
    closeMenu: string;
    phaseBadge: string;
  };
  // Hero Section
  hero: {
    badge: string;
    headline: string;
    supportingText: string;
    getStarted: string;
    exploreServices: string;
    activeUsersBadge: string;
    activeUsersText: string;
    securityBadge: string;
  };
  // Portal Cards Section
  portals: {
    sectionBadge: string;
    sectionTitle: string;
    sectionSubtitle: string;
    doctorTitle: string;
    doctorDesc: string;
    doctorCta: string;
    doctorBadge: string;
    staffTitle: string;
    staffDesc: string;
    staffCta: string;
    staffBadge: string;
    patientTitle: string;
    patientDesc: string;
    patientCta: string;
    patientBadge: string;
    modalTitle: string;
    modalNotice: string;
    modalCredentials: string;
    modalEmail: string;
    modalPassword: string;
    modalClose: string;
  };
  // Key Features Section
  features: {
    sectionBadge: string;
    sectionTitle: string;
    sectionSubtitle: string;
    feature1Title: string;
    feature1Desc: string;
    feature2Title: string;
    feature2Desc: string;
    feature3Title: string;
    feature3Desc: string;
    feature4Title: string;
    feature4Desc: string;
    feature5Title: string;
    feature5Desc: string;
  };
  // Platform Introduction
  platformIntro: {
    sectionBadge: string;
    sectionTitle: string;
    sectionSubtitle: string;
    staffStepTitle: string;
    staffStepDesc: string;
    doctorStepTitle: string;
    doctorStepDesc: string;
    patientStepTitle: string;
    patientStepDesc: string;
    disclaimerTitle: string;
    disclaimerText: string;
  };
  // Get Started / Closing CTA Section
  cta: {
    badge: string;
    title: string;
    subtitle: string;
    primaryButton: string;
    secondaryButton: string;
  };
  // Footer
  footer: {
    description: string;
    quickLinksTitle: string;
    home: string;
    aboutUs: string;
    services: string;
    contact: string;
    portalsTitle: string;
    doctorPortal: string;
    staffPortal: string;
    patientPortal: string;
    supportTitle: string;
    emailLabel: string;
    emailVal: string;
    phoneLabel: string;
    phoneVal: string;
    addressLabel: string;
    addressVal: string;
    privacy: string;
    terms: string;
    copyright: string;
    medicalDisclaimer: string;
  };
  // Common / Modals
  common: {
    phaseNoticeTitle: string;
    phaseNoticeDesc: string;
    okButton: string;
    demoNote: string;
    activeRole: string;
  };
}

export const translations: Record<Language, Translations> = {
  en: {
    nav: {
      brandName: 'Trails Monitor Hub',
      brandTagline: 'Unified Healthcare System',
      home: 'Home',
      aboutUs: 'About Us',
      services: 'Services',
      contact: 'Contact',
      login: 'Login',
      languageToggle: 'हिंदी',
      openMenu: 'Open main menu',
      closeMenu: 'Close menu',
      phaseBadge: 'Phase 1 Active',
    },
    hero: {
      badge: 'Healthcare Management Platform',
      headline: 'Connected Healthcare. Better Patient Outcomes.',
      supportingText:
        'Trails Monitor Hub is a unified healthcare management platform that connects doctors, hospital staff, and patients through coordinated clinical workflows, organized medical records, and transparent patient communication.',
      getStarted: 'Get Started',
      exploreServices: 'Explore Services',
      activeUsersBadge: 'Coordinated Care',
      activeUsersText: 'Doctors • Hospital Staff • Patients in sync',
      securityBadge: 'Standardized Healthcare Design System',
    },
    portals: {
      sectionBadge: 'Role-Specific Access',
      sectionTitle: 'Dedicated Portals for Every Stakeholder',
      sectionSubtitle:
        'Select your portal to experience tailored clinical, administrative, or patient-centric workflows.',
      doctorTitle: 'Doctor Portal',
      doctorDesc:
        'Manage patients, review comprehensive medical records, conduct consultations, and monitor available health information with high-efficiency clinical tools.',
      doctorCta: 'Doctor Login',
      doctorBadge: 'Clinical Workspace',
      staffTitle: 'Hospital Staff Portal',
      staffDesc:
        'Register new and emergency patients, organize doctor appointments, manage hospital queues, and ensure rapid triage across hospital departments.',
      staffCta: 'Staff Login',
      staffBadge: 'Administrative Operations',
      patientTitle: 'Patient Portal',
      patientDesc:
        'Access personal medical records, diagnostic test reports, upcoming appointments, live queue updates, and simple assistance tools anytime.',
      patientCta: 'Patient Login',
      patientBadge: 'Accessible Healthcare',
      modalTitle: 'Portal Entry Details',
      modalNotice:
        'Full portal authentication and role-specific dashboards will be unlocked in Phase 2 & subsequent phases according to the project roadmap.',
      modalCredentials: 'Phase 2 Development Credentials:',
      modalEmail: 'Email',
      modalPassword: 'Password',
      modalClose: 'Close Window',
    },
    features: {
      sectionBadge: 'Core Capabilities',
      sectionTitle: 'Everything Modern Healthcare Requires',
      sectionSubtitle:
        'Engineered to streamline hospital operations, remove paperwork bottlenecks, and place the patient at the heart of care delivery.',
      feature1Title: 'Unified Patient Records',
      feature1Desc:
        'Centralized, chronological patient history aggregating diagnoses, prescriptions, lab results, and allergies without duplicated data entry.',
      feature2Title: 'Appointment & Queue Management',
      feature2Desc:
        'Real-time queue tracking for OPD patients, transparent wait-time visibility, and smooth handovers between triage staff and doctors.',
      feature3Title: 'Medical Reports & Health Monitoring',
      feature3Desc:
        'Structured lab report access, longitudinal vitals tracking (ECG, Heart Rate, SpO2, BP), and organized organ-specific clinical observations.',
      feature4Title: 'Emergency Assistance',
      feature4Desc:
        'Rapid emergency registration workflows, priority queue tagging, and immediate one-tap Call for Help capabilities for unwell patients.',
      feature5Title: 'Connected Healthcare Management',
      feature5Desc:
        'Seamless communication bridge synchronizing compounders, receptionists, clinical specialists, and patients in a unified ecosystem.',
    },
    platformIntro: {
      sectionBadge: 'Unified Ecosystem',
      sectionTitle: 'How Trails Monitor Hub Connects the Care Team',
      sectionSubtitle:
        'Healthcare works best when doctors, administrative staff, and patients share a single source of truth.',
      staffStepTitle: '1. Fast Intake & Queueing',
      staffStepDesc:
        'Hospital staff registers patients with unique IDs, manages walk-ins, assigns priority levels, and directs patients into the smart consultation queue.',
      doctorStepTitle: '2. Clinical Assessment & Documentation',
      doctorStepDesc:
        'Doctors instantly review patient history, enter consultation notes, prescribe medications, and order laboratory diagnostics in an auditable workflow.',
      patientStepTitle: '3. Transparent Care & Empowerment',
      patientStepDesc:
        'Patients monitor their visit status, check prescription reminders, review lab findings, and maintain a lightweight Health Diary in their preferred language.',
      disclaimerTitle: 'Healthcare Prototype Notice',
      disclaimerText:
        'Trails Monitor Hub Phase 1 presents the public foundation and user interface architecture. Direct medical device telemetry and live hospital hardware integrations will follow in subsequent integration phases.',
    },
    cta: {
      badge: 'Start Your Journey',
      title: 'Ready to Experience Coordinated Healthcare?',
      subtitle:
        'Select your role above to preview dedicated workflows designed for doctors, staff, and patients.',
      primaryButton: 'Select Your Portal',
      secondaryButton: 'Learn More in Documentation',
    },
    footer: {
      description:
        'Trails Monitor Hub is an enterprise healthcare management platform bringing patient registration, clinical consultations, queueing, and health records into one unified system.',
      quickLinksTitle: 'Platform Navigation',
      home: 'Home',
      aboutUs: 'About Us',
      services: 'Services',
      contact: 'Contact',
      portalsTitle: 'Role Portals',
      doctorPortal: 'Doctor Portal',
      staffPortal: 'Hospital Staff Portal',
      patientPortal: 'Patient Portal',
      supportTitle: 'Contact & Support',
      emailLabel: 'Support Email',
      emailVal: 'support@trailsmonitor.demo',
      phoneLabel: 'Helpline',
      phoneVal: '+91 1800-000-DEMO (Toll-Free)',
      addressLabel: 'Headquarters',
      addressVal: 'Healthcare Innovation District, New Delhi, India',
      privacy: 'Privacy Safeguards',
      terms: 'Terms of Use',
      copyright: '© 2026 Trails Monitor Hub. All rights reserved.',
      medicalDisclaimer:
        'Disclaimer: Trails Monitor Hub is a demonstration healthcare management system. Simulated vitals and demo records are for development evaluation.',
    },
    common: {
      phaseNoticeTitle: 'Feature Availability',
      phaseNoticeDesc:
        'This public page will be implemented in Phase 2 (Public Pages & Login System) following the project roadmap.',
      okButton: 'Got it',
      demoNote: 'Prototype Mode',
      activeRole: 'Selected Role',
    },
  },
  hi: {
    nav: {
      brandName: 'ट्रेल्स मॉनिटर हब',
      brandTagline: 'एकीकृत स्वास्थ्य सेवा प्रणाली',
      home: 'होम',
      aboutUs: 'हमारे बारे में',
      services: 'सेवाएं',
      contact: 'संपर्क करें',
      login: 'लॉगिन',
      languageToggle: 'English',
      openMenu: 'मुख्य मेनू खोलें',
      closeMenu: 'मेनू बंद करें',
      phaseBadge: 'फेज 1 सक्रिय',
    },
    hero: {
      badge: 'स्वास्थ्य प्रबंधन मंच',
      headline: 'संबद्ध स्वास्थ्य सेवा। बेहतर रोगी परिणाम।',
      supportingText:
        'ट्रेल्स मॉनिटर हब एक एकीकृत स्वास्थ्य प्रबंधन मंच है जो डॉक्टरों, अस्पताल के कर्मचारियों और रोगियों को समन्वित चिकित्सीय कार्यप्रवाह, व्यवस्थित मेडिकल रिकॉर्ड और स्पष्ट रोगी संचार के माध्यम से जोड़ता है।',
      getStarted: 'शुरू करें',
      exploreServices: 'सेवाएं देखें',
      activeUsersBadge: 'समन्वित देखभाल',
      activeUsersText: 'डॉक्टर • अस्पताल कर्मचारी • रोगी एक साथ जुड़े',
      securityBadge: 'मानकीकृत स्वास्थ्य सेवा डिज़ाइन प्रणाली',
    },
    portals: {
      sectionBadge: 'भूमिका-विशिष्ट पहुंच',
      sectionTitle: 'प्रत्येक हितधारक के लिए समर्पित पोर्टल',
      sectionSubtitle:
        'अनुकूलित चिकित्सीय, प्रशासनिक या रोगी-केंद्रित कार्यप्रवाह का अनुभव करने के लिए अपना पोर्टल चुनें।',
      doctorTitle: 'डॉक्टर पोर्टल',
      doctorDesc:
        'मरीजों का प्रबंधन करें, संपूर्ण मेडिकल रिकॉर्ड की समीक्षा करें, परामर्श दें और उच्च-दक्षता वाले क्लिनिकल टूल्स के साथ उपलब्ध स्वास्थ्य जानकारी की निगरानी करें।',
      doctorCta: 'डॉक्टर लॉगिन',
      doctorBadge: 'क्लिनिकल कार्यक्षेत्र',
      staffTitle: 'अस्पताल स्टाफ पोर्टल',
      staffDesc:
        'नए और आपातकालीन रोगियों का पंजीकरण करें, डॉक्टर के अपॉइंटमेंट आयोजित करें, अस्पताल की कतारों का प्रबंधन करें और त्वरित ट्राइएज सुनिश्चित करें।',
      staffCta: 'स्टाफ लॉगिन',
      staffBadge: 'प्रशासनिक संचालन',
      patientTitle: 'रोगी पोर्टल',
      patientDesc:
        'व्यक्तिगत मेडिकल रिकॉर्ड, डायग्नोस्टिक टेस्ट रिपोर्ट, आगामी अपॉइंटमेंट, लाइव कतार अपडेट और सरल सहायता टूल कभी भी एक्सेस करें।',
      patientCta: 'मरीज़ लॉगिन',
      patientBadge: 'सुलभ स्वास्थ्य सेवा',
      modalTitle: 'पोर्टल प्रवेश विवरण',
      modalNotice:
        'परियोजना रोडमैप के अनुसार पूर्ण पोर्टल प्रमाणीकरण और भूमिका-विशिष्ट डैशबोर्ड चरण 2 और बाद के चरणों में अनलॉक किए जाएंगे।',
      modalCredentials: 'फेज 2 विकास क्रेडेंशियल:',
      modalEmail: 'ईमेल',
      modalPassword: 'पासवर्ड',
      modalClose: 'विंडो बंद करें',
    },
    features: {
      sectionBadge: 'मुख्य क्षमताएं',
      sectionTitle: 'आधुनिक स्वास्थ्य सेवा के लिए आवश्यक सब कुछ',
      sectionSubtitle:
        'अस्पताल के संचालन को सुव्यवस्थित करने, कागजी कार्रवाई की बाधाओं को दूर करने और रोगी को देखभाल के केंद्र में रखने के लिए निर्मित।',
      feature1Title: 'एकीकृत रोगी रिकॉर्ड',
      feature1Desc:
        'निदान, नुस्खे, लैब परिणाम और एलर्जी को बिना दोबारा डेटा प्रविष्टि के एकत्रित करने वाला केंद्रीकृत, कालानुक्रमिक रोगी इतिहास।',
      feature2Title: 'नियुक्ति और कतार प्रबंधन',
      feature2Desc:
        'ओपीडी रोगियों के लिए रीयल-टाइम कतार ट्रैकिंग, प्रतीक्षा समय की स्पष्ट दृश्यता और ट्राइएज स्टाफ और डॉक्टरों के बीच सुगम समन्वय।',
      feature3Title: 'चिकित्सा रिपोर्ट और स्वास्थ्य निगरानी',
      feature3Desc:
        'व्यवस्थित लैब रिपोर्ट एक्सेस, निरंतर वाइटल्स ट्रैकिंग (ईसीजी, हृदय गति, SpO2, रक्तचाप) और अंग-विशिष्ट क्लिनिकल अवलोकन।',
      feature4Title: 'आपातकालीन सहायता',
      feature4Desc:
        'त्वरित आपातकालीन पंजीकरण कार्यप्रवाह, प्राथमिकता कतार टैगिंग और अस्वस्थ रोगियों के लिए तत्काल वन-टैप सहायता कॉल क्षमताएं।',
      feature5Title: 'संबद्ध स्वास्थ्य सेवा प्रबंधन',
      feature5Desc:
        'एक एकीकृत पारिस्थितिकी तंत्र में कंपाउंडरों, रिसेप्शनिस्टों, क्लिनिकल विशेषज्ञों और रोगियों को जोड़ने वाला निर्बाध संचार पुल।',
    },
    platformIntro: {
      sectionBadge: 'एकीकृत पारिस्थितिकी तंत्र',
      sectionTitle: 'ट्रेल्स मॉनिटर हब देखभाल दल को कैसे जोड़ता है',
      sectionSubtitle:
        'स्वास्थ्य सेवा तब सबसे अच्छी होती है जब डॉक्टर, प्रशासनिक कर्मचारी और मरीज़ एक ही विश्वसनीय प्रणाली साझा करते हैं।',
      staffStepTitle: '1. त्वरित पंजीकरण और कतारबद्धता',
      staffStepDesc:
        'अस्पताल कर्मचारी अद्वितीय आईडी के साथ रोगियों को पंजीकृत करते हैं, वॉक-इन संभालते हैं, प्राथमिकता तय करते हैं और स्मार्ट कतार में निर्देशित करते हैं।',
      doctorStepTitle: '2. क्लिनिकल मूल्यांकन और दस्तावेज़ीकरण',
      doctorStepDesc:
        'डॉक्टर तुरंत रोगी के इतिहास की समीक्षा करते हैं, परामर्श नोट्स दर्ज करते हैं, दवाएं लिखते हैं और प्रयोगशाला परीक्षणों का आदेश देते हैं।',
      patientStepTitle: '3. पारदर्शी देखभाल और सशक्तिकरण',
      patientStepDesc:
        'मरीज़ अपनी यात्रा की स्थिति की निगरानी करते हैं, दवा रिमाइंडर देखते हैं, लैब निष्कर्षों की समीक्षा करते हैं और अपनी पसंदीदा भाषा में स्वास्थ्य डायरी रखते हैं।',
      disclaimerTitle: 'स्वास्थ्य सेवा प्रोटोटाइप सूचना',
      disclaimerText:
        'ट्रेल्स मॉनिटर हब चरण 1 सार्वजनिक आधार और यूजर इंटरफेस आर्किटेक्चर प्रस्तुत करता है। प्रत्यक्ष चिकित्सा उपकरण टेलीमेट्री और लाइव अस्पताल एकीकरण आगामी चरणों में जुड़ेंगे।',
    },
    cta: {
      badge: 'अपनी यात्रा शुरू करें',
      title: 'समन्वित स्वास्थ्य सेवा का अनुभव करने के लिए तैयार हैं?',
      subtitle:
        'डॉक्टरों, कर्मचारियों और रोगियों के लिए डिज़ाइन किए गए समर्पित कार्यप्रवाहों का पूर्वावलोकन करने के लिए ऊपर अपनी भूमिका चुनें।',
      primaryButton: 'अपना पोर्टल चुनें',
      secondaryButton: 'दस्तावेज़ीकरण में अधिक जानें',
    },
    footer: {
      description:
        'ट्रेल्स मॉनिटर हब एक एंटरप्राइज़ हेल्थकेयर प्रबंधन मंच है जो रोगी पंजीकरण, क्लिनिकल परामर्श, कतार प्रबंधन और स्वास्थ्य रिकॉर्ड को एक एकीकृत प्रणाली में लाता है।',
      quickLinksTitle: 'प्लेटफ़ॉर्म नेविगेशन',
      home: 'होम',
      aboutUs: 'हमारे बारे में',
      services: 'सेवाएं',
      contact: 'संपर्क करें',
      portalsTitle: 'भूमिका पोर्टल',
      doctorPortal: 'डॉक्टर पोर्टल',
      staffPortal: 'अस्पताल स्टाफ पोर्टल',
      patientPortal: 'रोगी पोर्टल',
      supportTitle: 'संपर्क और सहायता',
      emailLabel: 'सहायता ईमेल',
      emailVal: 'support@trailsmonitor.demo',
      phoneLabel: 'हेल्पलाइन',
      phoneVal: '+91 1800-000-DEMO (टोल-फ्री)',
      addressLabel: 'मुख्यालय',
      addressVal: 'हेल्थकेयर इनोवेशन डिस्ट्रिक्ट, नई दिल्ली, भारत',
      privacy: 'गोपनीयता सुरक्षा',
      terms: 'उपयोग की शर्तें',
      copyright: '© 2026 ट्रेल्स मॉनिटर हब। सर्वाधिकार सुरक्षित।',
      medicalDisclaimer:
        'अस्वीकरण: ट्रेल्स मॉनिटर हब एक प्रदर्शन स्वास्थ्य प्रबंधन प्रणाली है। सिम्युलेटेड वाइटल्स और डेमो रिकॉर्ड विकास मूल्यांकन के लिए हैं।',
    },
    common: {
      phaseNoticeTitle: 'सुविधा उपलब्धता',
      phaseNoticeDesc:
        'यह सार्वजनिक पृष्ठ प्रोजेक्ट रोडमैप के अनुसार चरण 2 (सार्वजनिक पृष्ठ और लॉगिन सिस्टम) में लागू किया जाएगा।',
      okButton: 'समझ गया',
      demoNote: 'प्रोटोटाइप मोड',
      activeRole: 'चयनित भूमिका',
    },
  },
};
