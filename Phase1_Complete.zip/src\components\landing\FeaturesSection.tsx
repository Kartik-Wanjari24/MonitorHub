import React from 'react';
import { useLanguage } from '../../i18n/useLanguage';
import {
  FileText,
  UsersRound,
  Activity,
  AlertTriangle,
  Network,
  CheckCircle,
} from 'lucide-react';

export const FeaturesSection: React.FC = () => {
  const { t } = useLanguage();

  const features = [
    {
      id: 1,
      title: t.features.feature1Title,
      description: t.features.feature1Desc,
      icon: FileText,
      iconBg: 'bg-blue-100 text-blue-700',
      badge: 'Zero Redundancy',
    },
    {
      id: 2,
      title: t.features.feature2Title,
      description: t.features.feature2Desc,
      icon: UsersRound,
      iconBg: 'bg-indigo-100 text-indigo-700',
      badge: 'Real-Time OPD',
    },
    {
      id: 3,
      title: t.features.feature3Title,
      description: t.features.feature3Desc,
      icon: Activity,
      iconBg: 'bg-emerald-100 text-emerald-700',
      badge: 'Chronological Vitals',
    },
    {
      id: 4,
      title: t.features.feature4Title,
      description: t.features.feature4Desc,
      icon: AlertTriangle,
      iconBg: 'bg-rose-100 text-rose-700',
      badge: 'Rapid Triage',
    },
    {
      id: 5,
      title: t.features.feature5Title,
      description: t.features.feature5Desc,
      icon: Network,
      iconBg: 'bg-sky-100 text-sky-700',
      badge: 'Care Team Sync',
    },
  ];

  return (
    <section id="services" className="py-20 bg-slate-50 relative border-y border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16 space-y-4">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-blue-100/70 text-blue-800 border border-blue-200/60">
            <CheckCircle className="w-3.5 h-3.5 text-blue-600" />
            <span>{t.features.sectionBadge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            {t.features.sectionTitle}
          </h2>
          <p className="text-base sm:text-lg text-slate-600">
            {t.features.sectionSubtitle}
          </p>
        </div>

        {/* Feature Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            const isLast = idx === features.length - 1;
            return (
              <div
                key={feature.id}
                className={`bg-white rounded-2xl p-7 border border-slate-200/90 shadow-xs hover:shadow-lg transition-all duration-300 flex flex-col justify-between ${
                  isLast ? 'md:col-span-2 lg:col-span-1' : ''
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-5">
                    <div
                      className={`w-12 h-12 rounded-xl ${feature.iconBg} flex items-center justify-center shadow-xs`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-[11px] font-semibold text-slate-500 bg-slate-100 px-2.5 py-1 rounded-md">
                      {feature.badge}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-slate-900 mb-2">
                    {feature.title}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {feature.description}
                  </p>
                </div>

                <div className="mt-6 pt-4 border-t border-slate-100 flex items-center gap-1.5 text-xs font-semibold text-blue-600">
                  <CheckCircle className="w-3.5 h-3.5" />
                  <span>Standardized Clinical Workflow</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
